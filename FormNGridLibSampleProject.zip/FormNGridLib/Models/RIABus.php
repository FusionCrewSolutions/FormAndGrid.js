<?php

$segments = explode('/', trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/'));
$module = $segments[count($segments) - 2];
$param = $segments[count($segments) - 1];

if($module =="UserLog")
{
	include("User.php");	
	$usr = new user();
	
	if($param=="login"){echo $usr->uLogin();}
	if($param=="logout"){echo $usr->uLogout();}
}


if($module =="Items")
{
	include("Item.php");
	$itm = new Item();
	
	if($_SERVER['REQUEST_METHOD']=="GET")
	{
		$page=1;
		if($param!="null"){$page=$param;} 
		echo $itm->loadItems($page);
	}
	
	if($_SERVER['REQUEST_METHOD']=="POST")
	{
		if($param=="null")
		{
			echo $itm->saveItem($_POST['txtItemName'],$_POST['txtItemDesc']);
		}
		else
		{
			echo $itm->updateItem($param,$_POST['txtItemName'],$_POST['txtItemDesc']);
		}
	}

	if($_SERVER['REQUEST_METHOD']=="DELETE")
	{
		echo $itm->removeItem($param);
	}
}
?>