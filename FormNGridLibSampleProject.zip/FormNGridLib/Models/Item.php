<?php
$con=mysqli_connect("localhost","root","","formngrid") or die("DB Connection Error");


class Item
{
   
   function loadItems($page = 1)
   {
      global $con;
      $grid=""; 
      $itemsInPage=5; //customizable
           
      try
      {
         $start = ($page > 1 ) ? (($page-1)*$itemsInPage): 0;
         
         //customizable
         $sql = "SELECT * FROM items LIMIT $start,".$itemsInPage;

         if ($result = mysqli_query($con,$sql))
         {
            if(mysqli_num_rows($result)==0)
            {
               $grid = "There are no items.";
            }
            
            //customizable
            $grid="<table border='1' cellspacing='1' cellpadding='1'><tr>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Edit</th>
            <th>Delete</th></tr>";
              
              
            while($row = mysqli_fetch_row($result))
            {
               $grid.="<tr>
                  <td>$row[0]</td>
                  <td>$row[1]</td>
                  <td>$row[2]</td>
                  <td><input name=\"btnEdit\" type=\"button\" id=\"btnEdit\" value=\"Edit\" data-id=\"$row[0]\"></td>
                  <td><input name=\"btnRemove\" type=\"button\" id=\"btnRemove\" value=\"Remove\" data-id=\"$row[0]\"></td>
                 </tr>";
                        
            }//END OF WHILE   
            
            $grid.="</table>";   
         }//END of IF
         else
         {
            $grid = "There are no items";
         }
      }
      catch(Exception $e)
      {
         $grid = "Error: ".$e->getMessage();
      }
      
      $grid.=$this->getPaginator($page, $itemsInPage);
      mysqli_close($con);  
         
      return $grid;     
   }
   
   public function getPaginator($page, $limit) 
   {
      global $con;
      $total = 0;
      $paginatorID="paginator";
      $pageClass="";
      $pageID="btnPage";
      
      
      try
      {
         //customizable
         $sql = "SELECT COUNT('id') FROM items";

         if ($result = mysqli_query($con,$sql))
         {
            if(mysqli_num_rows($result)!=0)
            {
               $row = mysqli_fetch_row($result);
               $total = $row[0];
            }
         }
      }
      catch(Exception $e){}

       $last       = ceil( $total / $limit );    
       $start      = ( ( $page - $limit) > 0 ) ? $page - $limit: 1;
       $end        = ( ( $page + $limit) < $last ) ? $page + $limit: $last;
       $pageClass= ($page == 1 )? "disabled" : "";
    
       $paginator       = '<ul id="' . $paginatorID . '">';       
       $paginator       .= '<li class="'.$pageClass.'" id="'.$pageID.'" data-pagenumber="'.($page - 1).'">&laquo;</li>';
    
    
       if ( $start > 1 ) 
       {
           $paginator   .= '<li id="'.$pageID.'" data-pageNumber="1">1</li>';
           $paginator   .= '<li class="disabled"><span>...</span></li>';
       }
    
       for ( $i = $start ; $i <= $end; $i++ ) 
       {
           $class  = ( $page == $i ) ? "active" : "";
           $paginator   .= '<li class="'.$pageClass.'" id="'.$pageID.'" data-pageNumber="'.$i.'">'.$i.'</li>';
       }
    
       if ( $end < $last ) 
       {
           $paginator   .= '<li class="disabled"><span>...</span></li>';
           $paginator   .= '<li id="'.$pageID.'" data-pageNumber="'.$last.'">'.$last.'</li>';
       }
    
    
       $pageClass= ( $page == $last ) ? "disabled" : "";
       $paginator       .= '<li class="'.$pageClass.'" id="'.$pageID.'" data-pageNumber="'.($page + 1).'">&raquo;</a></li>';
    
       $paginator       .= '</ul>';
    
       return $paginator;
   }
   
   
   
   function saveItem($name, $desc)
   {
      global $con;
   
      try
      {     
         $sql="INSERT INTO items VALUES (NULL, '$name', '$desc');";  
         mysqli_query($con,$sql) or die("Error while saving");       
         return $this->loadItems();
      }
      catch(Exception $e)
      {
         mysqli_close($con);
      }  
   }
   
   
   
   function updateItem($id, $name, $desc)
   {
      global $con;
   
      try
      {     
         $sql="UPDATE items SET Name='$name',Description='$desc' WHERE ID=$id";
         mysqli_query($con,$sql) or die("Error while updating");        
         return $this->loadItems();
      }
      catch(Exception $e)
      {
         mysqli_close($con);
         return "Error";
      }
   }
   
   
   
   function removeItem($id)
   {
      global $con;
   
      try
      {     
         $sql="DELETE FROM items WHERE ID=$id"; 
         mysqli_query($con,$sql) or die("Error while removing");  
               
         return $this->loadItems();
      }
      catch(Exception $e)
      {
         mysqli_close($con);
         return "error";
      }
   }
}
?>