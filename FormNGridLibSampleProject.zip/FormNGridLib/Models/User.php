<?php

class user
{
	function __construct()
	{		
		if(!isset($_SESSION["usr"]))
		{
			$_SESSION["username"] = "";
		}

	}
	
	function isValidUser()
	{
		if(!(isset($_SESSION["usr"]) && $_SESSION["usr"] != ""))
		{
			header("Location:index.php");
		}
	}
	
	function uLogin()
	{
		$_SESSION["usr"] = "logged";
		echo "valid";
	}
	
	
	function uLogout()
	{
		session_destroy();
		echo "valid";
	}
}



?>