<?php
	session_start();
	
	include("Models/User.php");
	include("Models/Item.php");
	
	$usr = new user();
	$usr->isValidUser();

	$itm = new Item(); 
	$itemGrid = $itm->loadItems();
?>
<!doctype html>
<html>
<head>
<style>
body{
	font-family:Verdana, Geneva, Tahoma, sans-serif;
	font-size:12px;
}
label
{
	width:80px;
	padding:5px;
	display:inline-block;
	
}
button 
{
	width:60px;
	height:30px;
	margin:5px;
}

#paginator
{
	list-style:none;
	list-style-type:none;
	float:left;
}

#paginator li
{
	display:inline-block;
	width:20px;
	height:20px;
	background-color:#dddddd;
	margin:5px;
	text-align:center;
	cursor:pointer;
}

#divItemsMsg
{
	height:30px;
	line-height:30px;
	vertical-align:middle;
	padding:5px;
}
</style>
<title>SRS</title>
<script src="Controllers/jquery-1.11.1.min.js"></script>
<script src="Controllers/FormNGridLib.js"></script>
<script src="Controllers/ControllerMain.js"></script>
</head>

<body>
<button id="btnLogout">Logout</button>

<br>

<h1>Items</h1>
<form id="frmItems">
  <label>Name:</label>
  <input name="txtItemName" type="text" id="txtItemName">
  <br>
  <label>Description:</label>
  <input name="txtItemDesc" type="text" id="txtItemDesc">
  <br>
  <div id="divItemsMsg"></div>
  <button id="btnSave" data-id="null">Save</button>
  <button id="btnCancel">Cancel</button>
  <button id="btnLoad" >Reload</button>
  <div id="divItemGrid">
    <?php echo $itemGrid; ?>
  </div>
</form>
</body>
</html>