$(document).ready(function () 
{
   FormNGridUserLog(
   {
      dComBus:"Models",
      userLoginModule:"UserLog",
      userLoginForm:"#frmLogin",
      userLoginFormDivMsg:"#divLoginMsg",
      userLonginButton:"#btnLogin", 
      userLongoutButton:"#btnLogout", 
      userLonginRedirect:"Items.php", 
      userLongoutRedirect:"index.php"
      CRUDPostCompleteFunction:""
   });
   
   FormNGridCRUD(
   {
      dComBus:"Models",
      CRUDModule:"Items",
      CRUDForm:"#frmItems",
      CRUDFormDivMsg:"#divItemsMsg",
      CRUDDivGrid:"#divItemGrid",
      CRUDDivGridBtnPage:"#btnPage",
      CRUDFormBtnLoad:"#btnLoad",
      CRUDFormBtnSave:"#btnSave",
      CRUDFormValidateFunction:"",
      CRUDFormBtnEdit:"#btnEdit",
      CRUDFormEditFunction:"loadItemForEdit",
      CRUDFormBtnRemove:"#btnRemove",
      CRUDGridReload:true
   });
});


//==LOGIN===========================================================================================
function isValidLogin()
{
   $("#divLoginMsg").html("");
   
   if($("#txtUName").val()=="")
   {
      $("#divLoginMsg").html("Enter username");
      clearMsg("#divLoginMsg");
      return false;
   }
   
   if($("#txtPWord").val()=="")
   {
      $("#divLoginMsg").html("Enter password");
      clearMsg("#divLoginMsg");
      return false;
   }  
   
   return true;
}



//==ITEMS===========================================================================
function isValidItem()
{
   return true;
}

function loadItemForEdit(editBtn)
{
   var tr = $(editBtn).closest("tr");
   var td = $(tr).find("td").first().next();
   
   $("#txtItemName").val($(td).html());
   td = $(td).next();
   $("#txtItemDesc").val($(td).html());
}

function clearItemsForm()
{
   $("#txtItemName").val("");
   $("#txtItemDesc").val("");
}

function doAfterCompleting()
{
   alert("do whatever here");
}
