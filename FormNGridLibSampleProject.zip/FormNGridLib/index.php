<?php
session_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script src="Controllers/jquery-1.11.1.min.js"></script>
<script src="Controllers/FormNGridLib.js"></script>
<script src="Controllers/ControllerMain.js"></script>
<title>SRS</title>
</head>

<body>
<h1>Welcome</h1>
<form id="frmLogin">Username: <input name="txtUName" type="text" id="txtUName"><br>
Password: <input name="txtPWord" type="text" id="txtPWord"><br>
<input name="btnLogin" type="button" id="btnLogin" value="Login">
<div id="divLoginMsg"></div>
</form>
</body>
</html>